import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

xl=pd.read_excel(r"C:\Users\Lenovo\nareshit info\electricity\electricity bill data.xlsx")
#dividing dependnt and independent variabls
x=xl.iloc[:,:-1] #iv
y=xl.iloc[:,-1] #dv

#test and train data 
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.20,random_state=0)

#fit and transform
from sklearn.linear_model import LinearRegression
regressor=LinearRegression()
regressor.fit(x_train,y_train)
y_pred=regressor.predict(x_test)

#plotting
plt.scatter(x_test, y_test,color='red')
plt.plot(x_train,regressor.predict(x_train),color='blue')
plt.title('Electricity Bill (Test set)')
plt.xlabel('Months')
plt.ylabel('Amount')
plt.show()

# slope
m_slope=regressor.coef_
print("slope:",m_slope)
#constant
c_intercept=regressor.intercept_
print("constant:",c_intercept)

#prediction 
prediction_month =int(input())
predicted=m_slope*prediction_month+c_intercept
print("predicted amount for future bill :",predicted)
